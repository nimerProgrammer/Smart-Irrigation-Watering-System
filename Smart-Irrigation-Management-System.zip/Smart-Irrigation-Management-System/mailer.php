<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "smart_irrigation_management_system";

$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require './vendor/autoload.php'; 

if (isset($_POST["mailer"])) {
    $email = $_POST["email"];

    $mail = new PHPMailer(true);

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $userID = $row["id"];
        $name = $row["firstname"];
        
        try {
            $mail->SMTPDebug = 0;
            $mail->isSMTP(); 
            $mail->Host = 'smtp.gmail.com'; 
            $mail->SMTPAuth = true; 
            $mail->Username = 'smartirrigationmanagement@gmail.com';
            $mail->Password = 'gajj ybdd uuqx mxip';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;
    
            $mail->setFrom('smartirrigationmanagement@gmail.com', 'Smart Irrigation Management System');
    
            $mail->addAddress($email, $name);
            $mail->isHTML(true); 
            
            $verification_code = substr(number_format(time() * rand(), 0, '', ''), 0, 6);
    
            $mail->Subject = 'Email Verification';
            $mail->Body    = '<p>Your verification code is: <b style="font-size: 30px;">' . $verification_code . '</p>';
    
            $mail->send();
            
            date_default_timezone_set('Asia/Manila');
    
            $currentDateTime = time();
    
            $date = date("F j, Y", $currentDateTime);
            $time = date("h:i A", $currentDateTime);
    
            $sql1 = "SELECT * FROM `verification_code` WHERE `user_id` = '$userID'";
            $result1 = $conn->query($sql1);
    
            if ($result1->num_rows > 0) {
                $row1 = $result1->fetch_assoc();
                $code_id = $row1["id"];
                $sql2 = "UPDATE `verification_code` SET `code`='$verification_code',
                `date`='$date', `time`='$time' WHERE `id`='$code_id'";
                $result2 = $conn->query($sql2);
    
                if ($result2) {
                    $_SESSION["codeID"] = $code_id;
                    $_SESSION["userID"] = $userID;
                    $_SESSION["email"] = $email;
                    $_SESSION["name"] = $name;
                    
                    echo json_encode(true);
                }
            }
            else {
                $sql3 = "INSERT INTO `verification_code`(`id`, `code`, `date`, `time`, `user_id`)
                VALUES (NULL, '$verification_code', '$date', '$time', $userID)";
                $result3 = $conn->query($sql3);
        
                if ($result3) {
                    $last_inserted_id = mysqli_insert_id($conn);
                    $_SESSION["userID"] = $userID;
                    $_SESSION["codeID"] = $last_inserted_id;
                    $_SESSION["email"] = $email;
                    $_SESSION["name"] = $name;

                    echo json_encode(true);
                }
            }
        } 
        catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            echo json_encode(false);
        }
    }
    else {
        echo json_encode(false);
    }
}

if (isset($_POST["resend_mail"])) {

    // Initialize PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->SMTPDebug = 0;
        $mail->isSMTP(); // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
        $mail->SMTPAuth = true; // Enable SMTP authentication
        $mail->Username = 'smartirrigationmanagement@gmail.com'; // SMTP username
        $mail->Password = 'gajj ybdd uuqx mxip'; // SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;// Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587; // TCP port to connect to

        // Sender info
        $mail->setFrom('smartirrigationmanagement@gmail.com', 'Smart Irrigation Management System');

        // Receiver info
        $mail->addAddress($_SESSION["email"], $_SESSION["name"]); // Add a recipient
        $mail->isHTML(true); // Set email format to HTML
        // Content
        $verification_code = substr(number_format(time() * rand(), 0, '', ''), 0, 6);


        $mail->Subject = 'Email Verification';
        $mail->Body    = '<p>Your verification code is: <b style="font-size: 30px;">' . $verification_code . '</p>';

        // Send the email
        $mail->send();
        // echo 'Verification code sent successfully';
        date_default_timezone_set('Asia/Manila');

        $currentDateTime = time();

        $date = date("F j, Y", $currentDateTime);
        $time = date("h:i A", $currentDateTime);
        
        $sql = "UPDATE `verification_code` SET `code`='$verification_code',
        `date`='$date', `time`='$time' WHERE `id`='". $_SESSION["codeID"] ."'";
        $result = $conn->query($sql);

        if ($result) {
            $_SESSION["alert"] =  array(
                "title" => "Succcess!",
                "message" => "Code resent!",
                "type" => "success"
            );
            echo json_encode(true);
        }
        
    } 
    catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        echo json_encode(false);
    }
}
?>