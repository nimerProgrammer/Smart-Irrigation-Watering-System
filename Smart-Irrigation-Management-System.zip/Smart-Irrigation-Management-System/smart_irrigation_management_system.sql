-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2024 at 04:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_irrigation_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `date`, `time`, `user_id`) VALUES
(1, 'May 18, 2024', '11:51 PM', 1),
(2, 'May 21, 2024', '08:53 AM', 1),
(3, 'May 21, 2024', '08:58 AM', 13),
(4, 'May 21, 2024', '09:14 AM', 1),
(5, 'May 21, 2024', '09:32 AM', 1),
(6, 'May 21, 2024', '09:34 AM', 13),
(7, 'May 22, 2024', '09:04 PM', 1),
(8, 'May 24, 2024', '11:28 AM', 1),
(9, 'May 28, 2024', '07:58 PM', 1),
(10, 'May 28, 2024', '08:01 PM', 13),
(11, 'June 2, 2024', '01:38 PM', 1),
(12, 'June 2, 2024', '01:40 PM', 13),
(13, 'June 2, 2024', '03:37 PM', 13),
(14, 'June 2, 2024', '05:25 PM', 13),
(15, 'June 2, 2024', '06:02 PM', 13),
(16, 'June 3, 2024', '06:28 PM', 1),
(17, 'June 3, 2024', '06:30 PM', 13),
(18, 'June 15, 2024', '05:42 PM', 1),
(19, 'June 15, 2024', '05:43 PM', 13),
(20, 'June 17, 2024', '12:03 PM', 1),
(21, 'June 17, 2024', '12:15 PM', 1),
(22, 'August 13, 2024', '08:10 PM', 1),
(23, 'August 13, 2024', '08:13 PM', 13),
(24, 'August 20, 2024', '02:33 PM', 1),
(25, 'August 20, 2024', '02:33 PM', 13),
(26, 'August 24, 2024', '11:06 AM', 1),
(27, 'September 7, 2024', '08:31 PM', 1),
(28, 'September 7, 2024', '08:48 PM', 13),
(29, 'September 7, 2024', '10:37 PM', 13),
(30, 'September 8, 2024', '10:32 PM', 13),
(31, 'September 18, 2024', '08:55 PM', 1),
(32, 'September 18, 2024', '08:59 PM', 13),
(33, 'October 10, 2024', '06:07 PM', 1),
(34, 'October 10, 2024', '06:11 PM', 13);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `middlename` varchar(20) DEFAULT NULL,
  `surname` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `birthdate` varchar(20) NOT NULL,
  `address` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `account_status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `surname`, `gender`, `birthdate`, `address`, `email`, `contact_number`, `username`, `password`, `usertype`, `account_status`) VALUES
(1, 'Admin', '', 'Administration', 'Male', '2024-05-22', 'Oras E. Samar', 'smartirrigationmanagement@gmail.com', '09122137559', 'admin', '$2y$10$fZqf1J67HyE6N5YYbmtaTOBUYv/qiHhnVogn6M/8aYBfFQ8pJQyqG', 'admin', 'Activated'),
(13, 'Client', '', 'Nimer', 'Male', '2024-05-23', 'fsdsf', 'rinachocama101@gmail.com', '+639898766559', 'user', '$2y$10$u0mFpH1PDbsVpOpKSROe2OFT1qVOXIrv87rU.XtukXE9ByOz3y.F2', 'user', 'Activated'),
(14, 'Cruz', '', 'Clarck dela', 'Male', '2024-09-27', 'Oras E. Samar', 'clarckcruz25@gmail.com', '09105742223', 'jhkjhkjhjkj', '$2y$10$W3adlHMM42rcOH4ImbAxdOmUplVq5HrH8gojMa3nwx42IqF35WOnO', 'user', 'Activated'),
(15, 'alysasdca', 'sdsds', 'sdasd', 'Male', '2024-10-04', 'sdasd', 'alyzzaroncales622@gmail.com', '09108488477', 'asdasd', '$2y$10$GVg8tSXwrtU/dn15fzZXAOWpSbdqS80jzgYi.Zl.QJT1PH01Yh6ay', 'user', 'Activated');

-- --------------------------------------------------------

--
-- Table structure for table `verification_code`
--

CREATE TABLE `verification_code` (
  `id` int(11) NOT NULL,
  `code` varchar(10) NOT NULL,
  `date` varchar(25) NOT NULL,
  `time` varchar(15) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `verification_code`
--

INSERT INTO `verification_code` (`id`, `code`, `date`, `time`, `user_id`) VALUES
(1, '145544', 'September 7, 2024', '08:30 PM', 1),
(2, '248047', 'September 7, 2024', '08:47 PM', 13),
(3, '642346', 'September 28, 2024', '05:39 PM', 14),
(4, '211469', 'September 28, 2024', '05:44 PM', 15);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `verification_code`
--
ALTER TABLE `verification_code`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `verification_code`
--
ALTER TABLE `verification_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `verification_code`
--
ALTER TABLE `verification_code`
  ADD CONSTRAINT `verification_code_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
