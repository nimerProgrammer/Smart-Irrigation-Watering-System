<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION["userID"])) {
    if ($_SESSION["userTYPE"] === "user") {
        $_SESSION["thisTab"] = "Dashboard";
        header("location: ./others/dashboard.php");
    }
    else if ($_SESSION["userTYPE"] === "admin") {
        $_SESSION["thisTab"] = "Dashboard";
        header("location: ./others/dashboard.php");
    }
} else {
    header("location: ./others/homePage.php");
}