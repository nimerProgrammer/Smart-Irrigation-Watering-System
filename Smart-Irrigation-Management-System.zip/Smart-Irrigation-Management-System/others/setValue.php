<script>
function setValue_edit_account(firstname, middlename, surname, gender, birthdate, address, contact_number, email, username) {
    $('#edit_firstname').val(firstname);
    $('#edit_middlename').val(middlename);
    $('#edit_surname').val(surname);
    $('#edit_gender').val(gender);
    $('#edit_birthdate').val(birthdate);
    $('#edit_address').val(address);
    $('#edit_contact_number').val(contact_number);
    $('#edit_email').val(email);
    $('#edit_username').val(username);
}
</script>