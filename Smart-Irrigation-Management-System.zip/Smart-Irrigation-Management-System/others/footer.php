<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2024 <a href="javascript:void(0)">Smart Irrigation Management System</a>.</strong>
    All rights reserved.
</footer>
<style>
    body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .content-wrapper {
        flex: 1;
    }

    footer {
        flex-shrink: 0;
    }
</style>

<!-- JQuery JS -->
<script src="../includes/jquery/jquery.js"></script>
<script src="../includes/jquery/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="../includes/bootstrap/js/bootstrap.min.js"></script>
<script src="../includes/bootstrap/js/new_bootstrap.min.js"></script>
<!-- AdminLTE JS -->
<script src="../includes/adminlte/js/adminlte.js"></script>
<!-- Font Awesome JS -->
<script src="../includes/fontawesome/js/all.min.js"></script>
<!-- SweetAlert JS -->
<script src="../includes/sweetalert/sweetalert.js"></script>
<!-- DataTables  & includes -->
<script src="../includes/datatables/jquery.dataTables.min.js"></script>
<script src="../includes/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../includes/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../includes/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../includes/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../includes/datatables-buttons/js/buttons.bootstrap4.min.js"></script>

</body>
</html>

<?php unset($_SESSION["alert"]) ?>