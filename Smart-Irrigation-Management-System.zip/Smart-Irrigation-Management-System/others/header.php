<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["userTYPE"])) {
    header("location: login.php");
}

$db_host = "localhost";
$db_username = "root";
$db_password = "";
$db_name = "smart_irrigation_management_system";

$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Smart Irrigation Management System<?= " - " . $_SESSION["thisTab"] ?></title>

    <link rel="shortcut icon" href="../assets/img/smartLogo.png" type="image/x-icon">
    <link href="../includes/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../includes/bootstrap/css/bootstrap.css">
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="../includes/adminlte/css/adminlte.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../includes/fontawesome/css/all.min.css">
    <!-- DataTables -->
    <link rel="stylesheet" href="../includes/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../includes/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="../includes/datatables-buttons/css/buttons.bootstrap4.min.css">
    <script src="../includes/jquery/jquery-3.6.0.min.js"></script>
    <style>
        .tooltip-container {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .tooltip {
            visibility: hidden;
            width: 120px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;
            position: absolute;
            z-index: 1;
            bottom: 125%; /* Adjust according to the desired position */
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .tooltip::after {
            content: "";
            position: absolute;
            top: 100%; /* Adjust according to the desired position */
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #333 transparent transparent transparent;
        }

        .tooltip-container:hover .tooltip {
            visibility: visible;
            opacity: 1;
        }



        .nav-treeview {
            background-color: #28a745; /* Success background color (green) */
            display: none; 
        }

        .nav-treeview .nav-item .nav-link {
            color: white; 
        }

        .nav-treeview .nav-item .nav-link.active {
            background-color: #218838; 
        }
    </style>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item dropdown no-arrow">
                    <a class="dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="../assets/img/default_user.png" class="img-circle elevation-2 me-1" alt="User Image" width="32" height="32">
                        <span class="d-none d-md-inline text-bold"><?= $_SESSION["Name"] ?></span>
                    </a>
                    <!-- Dropdown Menu Content -->
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" style="margin-top: 13px;" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="javascript:void(0)" data-toggle="modal" data-target="#developer_modal">
                            <i class="fas fa-code fa-sm fa-fw mr-2 text-gray-400"></i>
                            Developer
                        </a>
                        <a class="dropdown-item" href="javascript:void(0)" data-toggle="modal" data-target="#account_modal">
                            <i class="fas fa-lock fa-sm fa-fw mr-2 text-gray-400"></i>
                            Account
                        </a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item btn_logout" href="javascript:void(0)">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                            Logout
                        </a>
                    </div>
                </li>
            </ul>
        </nav>
        <aside class="main-sidebar sidebar-dark-success elevation-4 position-fixed" style="height: 100%;">
            <div class="sidebar">
                <div class="user-panel mt-3 d-flex">
                    <img id="sidebar-logo" src="../assets/img/smartLogo1.png" class="img-circle elevation-0 mt-1 ml-1" style="width: 50px; height: 50px; padding: 1px" alt="Header Image" class="original-size">
                    <div class="info">
                        <p class="d-block text-white text-bold" style="font-size: 17px;">Smart Irrigation<br>Management System</p>
                    </div>
                </div>
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <li class="nav-item">
                            <a href="javascript:void(0)" id="btn_dashboard" class="nav-link <?= $_SESSION["thisTab"] == "Dashboard" ? "active" : null ?>">
                                <i class="nav-icon fa-solid fa-chart-line"></i>
                                <p>Dashboard</p>
                                <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                            </a>
                        </li>
                        <?php if ($_SESSION["userTYPE"] === "user") : ?>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_features" class="nav-link has-treeview">
                                    <i class="nav-icon fa-solid fa-star"></i>
                                    <p>Features</p>
                                    <i id="btn_icon" class="right fa-solid fa-angle-right"></i>
                                </a>
                                <ul id="features_submenu" class="nav nav-treeview nav-sidebar" style="display: none;">
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" id="btn_real_time_monitoring" class="nav-link <?= $_SESSION["thisTab"] == "Real Time Monitoring" ? "active" : null ?>" style="font-size: 13px;">
                                            <i class="nav-icon fa-solid fa-clock ml-3" style="font-size: 15px;"></i>
                                            <p>Real Time Monitoring</p>
                                            <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" id="btn_automated_scheduling" class="nav-link <?= $_SESSION["thisTab"] == "Automated Scheduling" ? "active" : null ?>" style="font-size: 13px;">
                                            <i class="nav-icon fa-solid fa-calendar-check ml-3" style="font-size: 15px;"></i>
                                            <p>Automated Scheduling</p>
                                            <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" id="btn_smart_alerts" class="nav-link <?= $_SESSION["thisTab"] == "Smart Alerts" ? "active" : null ?>" style="font-size: 13px;">
                                            <i class="nav-icon fa-solid fa-bell ml-3" style="font-size: 15px;"></i>
                                            <p>Smart Alerts</p>
                                            <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="javascript:void(0)" id="btn_data_analytics" class="nav-link <?= $_SESSION["thisTab"] == "Data Analytics" ? "active" : null ?>" style="font-size: 13px;">
                                            <i class="nav-icon fa-solid fa-chart-bar ml-3" style="font-size: 15px;"></i>
                                            <p>Data Analytics</p>
                                            <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_water_usage" class="nav-link <?= $_SESSION["thisTab"] == "Water Usage" ? "active" : null ?>">
                                    <i class="nav-icon fa-solid fa-droplet"></i>
                                    <p>Water Usage</p>
                                    <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_soil_moisture" class="nav-link <?= $_SESSION["thisTab"] == "Soil Moisture" ? "active" : null ?>">
                                    <i class="nav-icon fa-solid fa-temperature-high"></i>
                                    <p>Soil Moisture</p>
                                    <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_settings" class="nav-link <?= $_SESSION["thisTab"] == "Settings" ? "active" : null ?>">
                                    <i class="nav-icon fa-solid fa-gear"></i>
                                    <p>Settings</p>
                                    <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                </a>
                            </li>
                        <?php endif ?>
                        <?php if ($_SESSION["userTYPE"] === "admin") : ?>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_user_management" class="nav-link <?= $_SESSION["thisTab"] == "User Management" ? "active" : null ?>">
                                    <i class="nav-icon fa-solid fa-user"></i>
                                    <p>User Management</p>
                                    <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_data_analytics" class="nav-link <?= $_SESSION["thisTab"] == "Data Analytics" ? "active" : null ?>">
                                    <i class="nav-icon fa-solid fa-chart-bar"></i>
                                    <p>Data Analytics</p>
                                    <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="javascript:void(0)" id="btn_reports" class="nav-link <?= $_SESSION["thisTab"] == "Reports" ? "active" : null ?>">
                                    <i class="nav-icon fa-solid fa-clipboard-list"></i>
                                    <p>Reports</p>
                                    <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                                </a>
                            </li>
                        <?php endif ?>
                    </ul>
                </nav>                
            </div>
            <div class="sidebar">
                <nav class="mt-0">
                    <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                        <div class="user-panel mb-2 pb-0 mb-0 d-flex"></div>
                        <li class="nav-item">
                            <a href="javascript:void(0)" class="nav-link btn_logout">
                                <i class="nav-icon fas fa-sign-out-alt"></i>
                                <p>Logout</p>
                                <div class="spinner-border spinner-border-sm text-success float-right d-none tab_spinner" role="status"></div>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
    </div>
    <script>
        // Optional JavaScript to handle the tooltip display
        const tooltipContainers = document.querySelectorAll('.tooltip-container');

        tooltipContainers.forEach(container => {
            container.addEventListener('mouseenter', () => {
                const tooltip = container.querySelector('.tooltip');
                tooltip.style.display = 'block';
            });

            container.addEventListener('mouseleave', () => {
                const tooltip = container.querySelector('.tooltip');
                tooltip.style.display = 'none';
            });
        });
    </script>
<?php include_once "./setValue.php" ?>
<?php include_once "./modals.php" ?>
<?php include_once "./script.php" ?>
<?php include_once "./server.php" ?>
