<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

date_default_timezone_set('Asia/Manila');

$db_host = "localhost";
$db_uname = "root";
$db_pass = "";
$db_name = "smart_irrigation_management_system";

$conn = new mysqli($db_host, $db_uname, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if (isset($_POST["login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $response = array();

    if (!isset($_SESSION["error_login"]) || $_SESSION["error_login"] > 2) {
        $_SESSION["error_login"] = 0;
    }

    $sql = "SELECT * FROM `users` WHERE `username` = '" . $username . "' AND account_status='Activated'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $user_id = $row["id"];
        $username = $row["username"];
        $user_type = $row["usertype"];
        $hashed_password = $row["password"];
    
        if (password_verify($password, $hashed_password)) {
            $_SESSION["userID"] = $row["id"];
            $_SESSION['userTYPE'] = $row["usertype"];
            $_SESSION['user'] = $user_type;
            $_SESSION['username'] = $username;
            $_SESSION['password'] = $password;

            $currentDateTime = time();

            $date = date("F j, Y", $currentDateTime);
            $time = date("h:i A", $currentDateTime);

            $sql_2 = "INSERT INTO `logs` (`id`, `date`, `time`, `user_id`) VALUES (NULL, '" . $date . "', '" . $time . "', '" . $user_id . "')";
            $result_2 = $conn->query($sql_2);

            if ($_SESSION['userTYPE'] == "user") {
                $_SESSION['Name'] = $row["firstname"];
                if ($row["middlename"] !== NULL) {
                    $_SESSION['Name'] .= " " . $row["middlename"];
                }
                $_SESSION['Name'] .= " " . $row["surname"];
                
                $response['status'] = 'success';
                echo json_encode($response);
            }
            else {
                $_SESSION['Name'] = "Administrator";
                $response['status'] = 'success';
                echo json_encode($response);
            }
        } 
        else {
            $_SESSION["error_login"] += 1;
            if ($_SESSION["error_login"] > 2) {
                $response['status'] = 'error_login';
                echo json_encode($response);
            }
            else {
                $response['status'] = 'error_password';
                echo json_encode($response);
            }
        }
    } 
    else {
        $_SESSION["error_login"] += 1;
        if ($_SESSION["error_login"] > 2) {
            $response['status'] = 'error_login';
            echo json_encode($response);
        }
        else {
            $response['status'] = 'error_username';
            echo json_encode($response);
        }
    }
}

if (isset($_POST["signUp_session"])) {
    $_SESSION["signUp"] = "true";
    echo json_encode(true);
}

if (isset($_POST["signup"])) {
    $firstname = mysqli_real_escape_string($conn, $_POST['firstname']);
    $middlename = mysqli_real_escape_string($conn, $_POST['middlename']);
    $surname = mysqli_real_escape_string($conn, $_POST['surname']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $birthdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $response = array();
    
    if ($middlename === NULL) {
        $middlename = NULL;
    }

    $sql4 ="SELECT * FROM users WHERE contact_number='$contact_number' AND account_status='Activated'";
    $result4 = $conn->query($sql4);
    if ($result4->num_rows > 0) {
        $response['status'] = 'error_contact_number';
        echo json_encode($response);
    }
    else {
        $sql1 ="SELECT * FROM users WHERE email='$email' AND account_status='Activated'";
        $result1 = $conn->query($sql1);
        if ($result1->num_rows > 0) {
            $response['status'] = 'error_email';
            echo json_encode($response);
        }
        else {
            $sql2 ="SELECT * FROM users WHERE username='$username' AND account_status='Activated'";
            $result2 = $conn->query($sql2);
            if ($result2->num_rows > 0) {
                $response['status'] = 'error_username';
                echo json_encode($response);
            }
            else {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);

                $sql3 = "INSERT INTO `users`(`id`, `firstname`, `middlename`, `surname`, `gender`, `birthdate`, `address`, `email`, `contact_number`, `username`, `password`, `usertype`, `account_status`) 
                VALUES (NULL,'$firstname','$middlename','$surname','$gender','$birthdate','$address','$email','$contact_number', '$username','$hashed_password','user','Activated')";
                $result3 = $conn->query($sql3);

                if ($result3) {
                    $_SESSION['alert'] = array(
                        'type' => 'success',
                        'title' => 'Congratulations!🎉',
                        'message' => 'Your account was successfully created!',
                        "button" => "OK",
                        "button_color" => "success"
                    );
                    unset($_SESSION['signUp']);
                    $response['status'] = 'success';
                    echo json_encode($response);
                }
            }
        }
    }
}

if (isset($_POST["dashboard"])) {
    $_SESSION["thisTab"] = "Dashboard";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["real_time_monitoring"])) {
    $_SESSION["thisTab"] = "Real Time Monitoring";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["automated_scheduling"])) {
    $_SESSION["thisTab"] = "Automated Scheduling";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["smart_alerts"])) {
    $_SESSION["thisTab"] = "Smart Alerts";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["data_analytics"])) {
    $_SESSION["thisTab"] = "Data Analytics";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["water_usage"])) {
    $_SESSION["thisTab"] = "Water Usage";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["soil_moisture"])) {
    $_SESSION["thisTab"] = "Soil Moisture";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["user_management"])) {
    $_SESSION["thisTab"] = "User Management";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["reports"])) {
    $_SESSION["thisTab"] = "Reports";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["settings"])) {
    $_SESSION["thisTab"] = "Settings";
    $_SESSION["alert"] = array(
        "title" => "Ooops!",
        "message" => "This feature is currently under development.",
        "type" => "warning",
        "button" => "OK",
        "button_color" => "success"
    );
    echo json_encode(true);
}

if (isset($_POST["logout"])) {
    unset($_SESSION["userID"]);
    unset($_SESSION['userTYPE']);
    unset($_SESSION["error_login"]);
    echo json_encode(true); 
}

if (isset($_POST["edit_account"])) {
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $surname = $_POST['surname'];
    $gender = $_POST['gender'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $contact_number = $_POST['contact_number'];
    $email = $_POST['email'];
    $username = $_POST['username'];

    $response = array();

    if ($middlename === NULL) {
        $middlename = NULL;
    }

    $sql ="SELECT * FROM users WHERE id='". $_SESSION["userID"] ."' AND account_status='Activated'";
    $result = $conn->query($sql);

    $sql3 ="SELECT * FROM users WHERE contact_number='$contact_number' AND account_status='Activated'";
    $result3 = $conn->query($sql3);

    $sql4 ="SELECT * FROM users WHERE email='$email' AND account_status='Activated'";
    $result4 = $conn->query($sql4);

    $sql5 ="SELECT * FROM users WHERE username='$username' AND account_status='Activated'";
    $result5 = $conn->query($sql5);

    $sql6 = "UPDATE `users` SET 
    `firstname`='" . mysqli_real_escape_string($conn, $firstname) . "',
    `middlename`='" . mysqli_real_escape_string($conn, $middlename) . "',
    `surname`='" . mysqli_real_escape_string($conn, $surname) . "',
    `gender`='" . mysqli_real_escape_string($conn, $gender) . "',
    `birthdate`='" . mysqli_real_escape_string($conn, $birthdate) . "',
    `address`='" . mysqli_real_escape_string($conn, $address) . "',
    `email`='" . mysqli_real_escape_string($conn, $email) . "',
    `contact_number`='" . mysqli_real_escape_string($conn, $contact_number) . "',
    `username`='" . mysqli_real_escape_string($conn, $username) . "' 
    WHERE id='" . mysqli_real_escape_string($conn, $_SESSION["userID"]) . "'";
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($contact_number === $row["contact_number"]) { 
            if ($email === $row["email"]) { 
                if ($username === $row["username"]) { 
                    $result6 = $conn->query($sql6);
                    if ($result6) {
                        $_SESSION["alert"] =  array(
                            "title" => "Succcess!",
                            "message" => "Account edited successfully!",
                            "type" => "success",
                            "button" => "OK",
                            "button_color" => "success"
                        );
                        $response['status'] = 'success';
                        echo json_encode($response);
                    }
                    else {
                        $_SESSION["alert"] =  array(
                            "title" => "Error!",
                            "message" => "Error while editing account!",
                            "type" => "error",
                            "button" => "OK",
                            "button_color" => "success"
                        );
                        $response['status'] = 'success';
                        echo json_encode($response);
                    }
                }
                else {
                    if ($result5->num_rows > 0) {
                        $response['status'] = 'error_username';
                        echo json_encode($response);
                    }
                    else {
                        $result6 = $conn->query($sql6);
                        if ($result6) {
                            $_SESSION["alert"] =  array(
                                "title" => "Succcess!",
                                "message" => "Account edited successfully!",
                                "type" => "success",
                                "button" => "OK",
                                "button_color" => "success"
                            );
                            $response['status'] = 'success';
                            echo json_encode($response);
                        }
                    }
                }
            }
            else {
                if ($result4->num_rows > 0) {
                    $response['status'] = 'error_email';
                    echo json_encode($response);
                }
                else {
                    if ($username === $row["username"]) { 
                        $result6 = $conn->query($sql6);
                        if ($result6) {
                            $_SESSION["alert"] =  array(
                                "title" => "Succcess!",
                                "message" => "Account edited successfully!",
                                "type" => "success",
                                "button" => "OK",
                                "button_color" => "success"
                            );
                            $response['status'] = 'success';
                            echo json_encode($response);
                        }
                        else {
                            $_SESSION["alert"] =  array(
                                "title" => "Error!",
                                "message" => "Error while editing account!",
                                "type" => "error",
                                "button" => "OK",
                                "button_color" => "success"
                            );
                            $response['status'] = 'success';
                            echo json_encode($response);
                        }
                    }
                    else {
                        if ($result5->num_rows > 0) {
                            $response['status'] = 'error_username';
                            echo json_encode($response);
                        }
                        else {
                            $result6 = $conn->query($sql6);
                            if ($result6) {
                                $_SESSION["alert"] =  array(
                                    "title" => "Succcess!",
                                    "message" => "Account edited successfully!",
                                    "type" => "success",
                                    "button" => "OK",
                                    "button_color" => "success"
                                );
                                $response['status'] = 'success';
                                echo json_encode($response);
                            }
                        }
                    }
                }
            }
        }
        else {
            if ($result3->num_rows > 0) {
                $response['status'] = 'error_contact_number';
                echo json_encode($response);
            }
            else {
                if ($email === $row["email"]) { 
                    if ($username === $row["username"]) { 
                        $result6 = $conn->query($sql6);
                        if ($result6) {
                            $_SESSION["alert"] =  array(
                                "title" => "Succcess!",
                                "message" => "Account edited successfully!",
                                "type" => "success",
                                "button" => "OK",
                                "button_color" => "success"
                            );
                            $response['status'] = 'success';
                            echo json_encode($response);
                        }
                        else {
                            $_SESSION["alert"] =  array(
                                "title" => "Error!",
                                "message" => "Error while editing account!",
                                "type" => "error",
                                "button" => "OK",
                                "button_color" => "success"
                            );
                            $response['status'] = 'success';
                            echo json_encode($response);
                        }
                    }
                    else {
                        if ($result5->num_rows > 0) {
                            $response['status'] = 'error_username';
                            echo json_encode($response);
                        }
                        else {
                            $result6 = $conn->query($sql6);
                            if ($result6) {
                                $_SESSION["alert"] =  array(
                                    "title" => "Succcess!",
                                    "message" => "Account edited successfully!",
                                    "type" => "success",
                                    "button" => "OK",
                                    "button_color" => "success"
                                );
                                $response['status'] = 'success';
                                echo json_encode($response);
                            }
                        }
                    }
                }
                else {
                    if ($result4->num_rows > 0) {
                        $response['status'] = 'error_email';
                        echo json_encode($response);
                    }
                    else {
                        if ($username === $row["username"]) { 
                            $result6 = $conn->query($sql6);
                            if ($result6) {
                                $_SESSION["alert"] =  array(
                                    "title" => "Succcess!",
                                    "message" => "Account edited successfully!",
                                    "type" => "success",
                                    "button" => "OK",
                                    "button_color" => "success"
                                );
                                $response['status'] = 'success';
                                echo json_encode($response);
                            }
                            else {
                                $_SESSION["alert"] =  array(
                                    "title" => "Error!",
                                    "message" => "Error while editing account!",
                                    "type" => "error",
                                    "button" => "OK",
                                    "button_color" => "success"
                                );
                                $response['status'] = 'success';
                                echo json_encode($response);
                            }
                        }
                        else {
                            if ($result5->num_rows > 0) {
                                $response['status'] = 'error_username';
                                echo json_encode($response);
                            }
                            else {
                                $result6 = $conn->query($sql6);
                                if ($result6) {
                                    $_SESSION["alert"] =  array(
                                        "title" => "Succcess!",
                                        "message" => "Account edited successfully!",
                                        "type" => "success",
                                        "button" => "OK",
                                        "button_color" => "success"
                                    );
                                    $response['status'] = 'success';
                                    echo json_encode($response);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if ($_SESSION['userTYPE'] === "user") {
        $_SESSION['Name'] = $firstname;
        $_SESSION['Name'] .= " " . $middlename;
        $_SESSION['Name'] .= " " . $surname;
    }
    
}

if (isset($_POST["email_verification"])) {
    $code = $_POST["code"];

    $sql = "SELECT * FROM verification_code WHERE code='$code' AND id ='". $_SESSION["codeID"] ."'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo json_encode(true);
        $_SESSION["change_password"] = "true";
    }
    else {
        echo json_encode(false);
    }
}

if (isset($_POST["change_password"])) {
    $newPassword = $_POST["newPassword"];

    $response = array();
    $hashed_password = password_hash($newPassword, PASSWORD_DEFAULT);

    $sql = "UPDATE users SET password='$hashed_password' WHERE id='". $_SESSION["userID"] ."'";
    $result = $conn->query($sql);

    if ($result) {
        $_SESSION["password"] = $newPassword;
        $_SESSION["alert"] =  array(
            "title" => "Succcess!",
            "message" => "Password updated!",
            "type" => "success",
            "button" => "OK",
            "button_color" => "success"
        );
        $response['status'] = 'success';
        echo json_encode($response);
    }
    else {
        $_SESSION["alert"] =  array(
            "title" => "Error!",
            "message" => "Error while changing password!",
            "type" => "error",
            "button" => "OK",
            "button_color" => "success"
        );
        $response['status'] = 'success';
        echo json_encode($response);
    }
}

if (isset($_POST["delete_account"])) {
    $sql = "UPDATE users SET account='Deactivated' WHERE id='". $_SESSION["userID"] ."'";
    $result = $conn->query($sql);

    if ($result) {
        $_SESSION["alert"] =  array(
            "title" => "Success!",
            "message" => "Account is deleted!",
            "type" => "success",
            "button" => "OK",
            "button_color" => "success"
        );
        echo json_encode(true);
    }
}
