<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["userTYPE"])) {
    header("location: login.php");
}
?>
<?php include_once "header.php" ?>

<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-lg-6">
                    <h2 class="mt-3 text-success">
                        <i class="nav-icon fa-solid fa-bell"></i>
                        Smart Alerts
                    </h2>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-lg-6">
                    <h1 class="mt-3 text-gray">
                        This feature is in progress.
                    </h1>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include_once "footer.php" ?>