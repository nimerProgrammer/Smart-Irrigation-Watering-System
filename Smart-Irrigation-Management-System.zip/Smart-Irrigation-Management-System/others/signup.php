<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION["signUp"])) {
    header("location: login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <!-- Bootstrap CSS -->
    <link href="../includes/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="../assets/img/smartLogo.png" type="image/x-icon">
    <!-- Custom CSS -->
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../includes/adminlte/css/adminlte.css">
    <style>
        body {
            background-image: url("../assets/img/homePage.png");
            background-repeat: no-repeat;
            background-size: cover;
        }

        .signup-container {
            margin-top: 30px;
        }

        .signup-card {
            border-radius: 5px;
        }

        .signup-header {
            color: rgb(0, 102, 255);
        }

        .signup-header h3 {
            margin-bottom: 0;
            font-weight: bold;
        }

        .signup-form select,
        .signup-form input[type="text"],
        .signup-form input[type="password"],
        .signup-form input[type="email"],
        .signup-form input[type="number"],
        .signup-form input[type="date"] {
            border: none;
            border-bottom: 1px solid green;
            border-radius: 0;
            box-shadow: none;
            margin-bottom: 20px;
        }

        .signup-form select:focus,
        .signup-form input[type="text"]:focus,
        .signup-form input[type="password"]:focus,
        .signup-form input[type="number"]:focus,
        .signup-form input[type="email"]:focus,
        .signup-form input[type="date"]:focus {
            border-color: green;
        }

        .signup-form .btn-signup {
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            padding: 12px 0;
            
            width: 100%;
            font-weight: bold;
        }

        .signup-form .btn-signup:hover {
            background-color: #218838;
        }

        .login-link {
            text-align: center;
        }

        .tooltip-container {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .tooltip {
            visibility: hidden;
            width: 120px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;
            position: absolute;
            z-index: 1;
            bottom: 125%; /* Adjust according to the desired position */
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .tooltip::after {
            content: "";
            position: absolute;
            top: 100%; /* Adjust according to the desired position */
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #333 transparent transparent transparent;
        }

        .tooltip-container:hover .tooltip {
            visibility: visible;
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="login-form">
        <div class="d-flex h-100 align-items-center justify-content-center">
            <div class="col-lg-9 signup-container">
                <div class="card signup-card">
                    <div class="card-header signup-header">
                        <a href="homePage.php" class="text-white">
                            <button type="button" class="float-right btn-danger tooltip-container">
                                <span aria-hidden="true">
                                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                                </span>
                                <div class="tooltip">Home</div>
                            </button>
                        </a>
                        <h3 class="text-success">Smart Irrigation Management System</h3>
                    </div>
                    <br>
                    <p class="text-center mb-0">Welcome! new user please sign up this form to create your account.</p>
                    <div class="card-body signup-form">
                        <form action="javascript:void(0)" id="signup_form">
                            <div class="row mr-3">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="firstname" name="firstname" placeholder="Firstname" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="middlename" name="middlename" placeholder="Middlename(optional)">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="surname" name="surname" placeholder="Surname" required>
                                    </div>
                                    <div class="form-group">
                                        <select class="custom-select" id="gender" required>
                                            <option value disabled selected>Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Tomboy">Tomboy</option>
                                            <option value="Gay">Gay</option>
                                            <option value="Rather not to say">Rather not to say</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="birthdate">Birthdate</label>
                                        <input type="date" class="form-control" id="birthdate" required>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control ml-4" id="address" name="address" placeholder="Address" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control ml-4" id="contact_number" name="contact_number" placeholder="Contact Number" required>
                                        <small class="text-danger d-none ml-4" id="error_contact_number">Contact number is already taken!</small>
                                        <small class="text-danger d-none ml-4" id="wrong_number">Contact number must start at (+63 or 09)!<br></small>
                                        <small class="text-danger d-none ml-4" id="long_number">Contact number must be 11 characters long!</small>
                                        <small class="text-danger d-none ml-4" id="long1_number">Contact number must be 13 characters long!</small>
                                    </div>
                                    <div class="form-group">
                                        <input type="email" class="form-control ml-4" id="email" name="email" placeholder="email@gmail.com" required>
                                        <small class="text-danger d-none ml-4" id="error_email">Email is already taken!</small>
                                        <small class="text-danger d-none ml-4" id="wrong_email">Wrong email format!</small>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control ml-4" id="username" name="username" placeholder="Username" required>
                                        <small class="text-danger d-none ml-4" id="error_username">Username is already taken!</small>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control ml-4" id="password" name="password" placeholder="Password" required>
                                        <small class="text-danger d-none ml-4" id="error_password">Password doesn't match!</small>
                                        <small class="text-danger d-none ml-4" id="error_password_length">Please input at list 8 characters!</small>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control ml-4" id="re_type_password" name="re_type_password" placeholder="Re-type-password" required>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-signup mt-3 text-white" id="btn_signup">Sign up</button>
                        </form>
                    </div>
                    <div class="login-link">
                        <p>Already have an account? <a href="login.php">Login</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
    
<!-- JQuery JS -->
<script src="../includes/jquery/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="../includes/bootstrap/js/new_bootstrap.min.js"></script>
<!-- AdminLTE JS -->
<script src="../includes/adminlte/js/adminlte.js"></script>
<!-- Font Awesome JS -->
<script src="../includes/fontawesome/js/all.min.js"></script>
<!-- SweetAlert JS -->
<script src="../includes/sweetalert/sweetalert.js"></script>
<script>
    // Optional JavaScript to handle the tooltip display
    const tooltipContainers = document.querySelectorAll('.tooltip-container');

    tooltipContainers.forEach(container => {
        container.addEventListener('mouseenter', () => {
            const tooltip = container.querySelector('.tooltip');
            tooltip.style.display = 'block';
        });

        container.addEventListener('mouseleave', () => {
            const tooltip = container.querySelector('.tooltip');
            tooltip.style.display = 'none';
        });
    });
</script>
<script>
$(document).ready(function() {
    var alert = <?= isset($_SESSION["alert"]) ? json_encode($_SESSION["alert"]) : json_encode(null) ?>;

    if (alert) {
        Swal.fire({
            title: alert.title,
            text: alert.message,
            icon: alert.type,
            confirmButtonText: alert.button,
            confirmButtonColor: alert.button_color === 'success' ? '#28a745' : '#3085d6'
        });
    }

    $('#contact_number').on('keydown input', function(e) {
        var value = $(this).val();

        // Allow only digits and + sign
        var regex = /^[0-9+]*$/;
        if (!regex.test(value)) {
            $(this).val(value.replace(/[^0-9+]/g, ''));
            return;
        }

        // Check for max length based on initial character
        var maxLength;
        if (value.startsWith('+')) {
            maxLength = 13;
        } else if (value.startsWith('0')) {
            maxLength = 11;
        } else {
            maxLength = 13; // Default max length for unexpected cases
        }

        // Prevent further input if max length is reached
        if ($(this).val().length >= maxLength && e.keyCode !== 8 && e.keyCode !== 46) {
            e.preventDefault();
        }

        // Ensure the + sign is only at the beginning
        if (value.indexOf('+') > 0) {
            $(this).val(value.replace(/\+/g, ''));
        }

        // Update the value to ensure only valid characters are present
        $(this).val(value);
    });
    
    $("#contact_number").keyup(function(){
        var maxLength = parseInt($(this).attr('maxlength'));
        if ($(this).val().length < maxLength) {
            $(this).css('color', 'red');

        } else {
            $(this).css('color', ''); 
        }
        $('#contact_number').on('input', function() {
            var contactNumber = $(this).val();
            
            if (contactNumber === null || contactNumber === "") {
                $('#long_number').addClass('d-none');
                $('#long1_number').addClass('d-none');
            } 
        })

        $("#contact_number").keyup(function(){
            var val = $('#contact_number').val();

            if (val.startsWith('+63')) {
                $(this).css('color', ''); 
                $('#wrong_number').addClass('d-none');
                $('#long_number').addClass('d-none');
                $('#long1_number').removeClass('d-none');
                $('#contact_number').removeClass('is-invalid');
                var contactNumber = val;
                if (contactNumber.length !== 13) {
                    $('#contact_number').css('color', 'red');
                    $('#wrong_number').addClass('d-none');
                    $('#long_number').addClass('d-none');
                    $('#long1_number').removeClass('d-none');
                    $('#contact_number').addClass('is-invalid');
                } else {
                    $('#contact_number').css('color', '');
                    $('#wrong_number').addClass('d-none');
                    $('#long_number').addClass('d-none');
                    $('#long1_number').addClass('d-none');
                    $('#contact_number').removeClass('is-invalid');
                }
            } 
            else if (val.startsWith('09')) {
                $(this).css('color', ''); 
                $('#wrong_number').addClass('d-none');
                $('#long_number').removeClass('d-none');
                $('#long1_number').addClass('d-none');
                $('#contact_number').removeClass('is-invalid');
                var contactNumber = val;
                if (contactNumber.length !== 11) {
                    $('#contact_number').css('color', 'red');
                    $('#long_number').removeClass('d-none');
                    $('#wrong_number').addClass('d-none');
                    $('#long1_number').addClass('d-none');
                    $('#contact_number').addClass('is-invalid');
                } else {
                    $('#contact_number').css('color', '');
                    $('#wrong_number').addClass('d-none');
                    $('#long1_number').addClass('d-none');
                    $('#long_number').addClass('d-none');
                    $('#contact_number').removeClass('is-invalid');
                }
            }
            else {
                $(this).css('color', 'red');
                $('#wrong_number').removeClass('d-none');
                $('#long1_number').addClass('d-none');
                $('#long_number').addClass('d-none');
                $('#contact_number').addClass('is-invalid');
            }
        });      
    });

    $("#email").on('input', function(){
        var email = $(this).val();
            if (!email.endsWith("@gmail.com")) {
            $(this).css('color', 'red');
            $('#wrong_email').removeClass('d-none');
            $('#email').addClass('is-invalid');
        } else {
            $(this).css('color', '');
            $('#wrong_email').addClass('d-none');
            $('#email').removeClass('is-invalid');
        }
    });
    
    $('#signup_form').submit(function(e) {

        var password = $("#password").val();
        if (password.length < 8) {
            event.preventDefault();
            $("#error_password_length").removeClass("d-none");
            return;
        }
        
        var val = $('#contact_number').val();
        var email = $('#email').val();
        
        if (val.startsWith('+63') || val.startsWith('09')) {
            if (val.startsWith('+63')) {
                $('#contact_number').css('color', ''); 
                $('#wrong_number').addClass('d-none');
                $('#long_number').addClass('d-none');
                $('#long1_number').addClass('d-none');
                $('#contact_number').removeClass('is-invalid');
                var contactNumber = val;
                if (contactNumber.length !== 13) {
                    $('#contact_number').css('color', 'red');
                    $('#wrong_number').addClass('d-none');
                    $('#long_number').addClass('d-none');
                    $('#long1_number').removeClass('d-none');
                    $('#contact_number').addClass('is-invalid');
                    return;
                } else {
                    $('#contact_number').css('color', '');
                    $('#wrong_number').addClass('d-none');
                    $('#long_number').addClass('d-none');
                    $('#long1_number').addClass('d-none');
                    $('#contact_number').removeClass('is-invalid');
                }
            }
            if (val.startsWith('09')) {
                $('#contact_number').css('color', ''); 
                $('#wrong_number').addClass('d-none');
                $('#long_number').addClass('d-none');
                $('#long1_number').addClass('d-none');
                $('#contact_number').removeClass('is-invalid');
                var contactNumber = val;
                if (contactNumber.length !== 11) {
                    $('#contact_number').css('color', 'red');
                    $('#long_number').removeClass('d-none');
                    $('#wrong_number').addClass('d-none');
                    $('#long1_number').addClass('d-none');
                    $('#contact_number').addClass('is-invalid');
                    return;
                } else {
                    $('#contact_number').css('color', '');
                    $('#wrong_number').addClass('d-none');
                    $('#long1_number').addClass('d-none');
                    $('#long_number').addClass('d-none');
                    $('#contact_number').removeClass('is-invalid');
                }
            }
        } 
        else {
            return;
        }
        if (email.endsWith('@gmail.com')) {
            $(this).css('color', ''); 
            $('#wrong_email').addClass('d-none');
            $('#email').removeClass('is-invalid');
        } 
        else {
            return;
        }
        // Collect form data
        var formData = new FormData();
        formData.append("firstname", $("#firstname").val());
        formData.append("middlename", $("#middlename").val());
        formData.append("surname", $("#surname").val());
        formData.append("gender", $("#gender").val());
        formData.append("birthdate", $("#birthdate").val());
        formData.append("address", $("#address").val());
        formData.append("contact_number", $("#contact_number").val());
        formData.append("email", $("#email").val());
        formData.append("username", $("#username").val());
        formData.append("password", $("#password").val());
        formData.append("signup", true);

        $("#btn_signup").attr("disabled", true);
        $("#btn_signup").text("Processing...");

        var password = $('#password').val();
        var reTypePassword = $('#re_type_password').val();
        if (password !== reTypePassword) {
            $("#btn_signup").removeAttr("disabled", true);
            $("#btn_signup").text("Sign up");

            $('#error_password').removeClass('d-none');
            $('#password').addClass('is-invalid');
            $('#re_type_password').addClass('is-invalid');
            return;
        } else {
            $('#error_password').addClass('d-none');
        }

        $.ajax({
            url: 'server.php',
            data: formData,
            type: 'POST',
            dataType: 'JSON',
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.status === 'success') {
                    location.href = "./login.php"
                }
                else if (response.status === 'error_contact_number') {
                    $("#btn_signup").removeAttr("disabled", true);
                    $("#btn_signup").text("Sign up");

                    $('#error_contact_number').removeClass('d-none');
                    $('#contact_number').addClass('is-invalid');

                    $("#error_email").addClass("d-none");
                    $("#email").removeClass("is-invalid");
                    $("#error_username").addClass("d-none");
                    $("#username").removeClass("is-invalid");
                    $("#error_password").addClass("d-none");
                    $("#password").removeClass("is-invalid");
                    $("#re_type_password").removeClass("is-invalid");
                }
                else if (response.status === 'error_email') {
                    $("#btn_signup").removeAttr("disabled", true);
                    $("#btn_signup").text("Sign up");

                    $('#error_email').removeClass('d-none');
                    $('#email').addClass('is-invalid');

                    $("#error_contact_number").addClass("d-none");
                    $("#contact_number").removeClass("is-invalid");
                    $("#error_username").addClass("d-none");
                    $("#username").removeClass("is-invalid");
                    $("#error_password").addClass("d-none");
                    $("#password").removeClass("is-invalid");
                    $("#re_type_password").removeClass("is-invalid");
                }
                else if (response.status === 'error_username') {
                    $("#btn_signup").removeAttr("disabled", true);
                    $("#btn_signup").text("Sign up");

                    $('#error_username').removeClass('d-none');
                    $('#username').addClass('is-invalid');

                    $("#error_contact_number").addClass("d-none");
                    $("#contact_number").removeClass("is-invalid");
                    $("#error_email").addClass("d-none");
                    $("#email").removeClass("is-invalid");
                    $("#error_password").addClass("d-none");
                    $("#password").removeClass("is-invalid");
                    $("#re_type_password").removeClass("is-invalid");
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
        
    });
    
    $("#contact_number").keypress(function() {
        $("#error_contact_number").addClass("d-none");
        $("#contact_number").removeClass("is-invalid");
        $('#wrong_number').addClass('d-none');
        $('#long_number').addClass('d-none');
        $('#long1_number').addClass('d-none');
    })
    $("#email").keypress(function() {
        $("#error_email").addClass("d-none");
        $("#email").removeClass("is-invalid");
    })
    $("#username").keypress(function() {
        $("#error_username").addClass("d-none");
        $("#username").removeClass("is-invalid");
    })
    $("#password").keypress(function() {
        $("#error_password").addClass("d-none");
        $("#password").removeClass("is-invalid");
        $("#re_type_password").removeClass("is-invalid");
        $("#error_password_length").addClass("d-none");
    })
    $("#re_type_password").keypress(function() {
        $("#error_password").addClass("d-none");
        $("#password").removeClass("is-invalid");
        $("#re_type_password").removeClass("is-invalid");
        $("#error_password_length").addClass("d-none");
    })
});
</script>
<?php include_once "./server.php" ?>
