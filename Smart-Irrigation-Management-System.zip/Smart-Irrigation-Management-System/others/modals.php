


<!-- Forgot Password Modal -->
<div class="modal fade" id="forgot_password_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-success ml-1" id="exampleModalLabel">Forgot Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="card-body">
                <p>Please enter your email/gmail account.</p>
                    <form action="javascript:void(0)" id="forgot_password_form">
                        <div class="row">
                            <div class="form-group mb-3 col-md-12">
                                <input type="text" class="form-control" id="email_account" placeholder="email@gmail.com" required>
                                <small class="text-danger d-none" id="error_email_account">Email not recognize!</small>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success w-100" id="btn_forgot_password_submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Developer Modal -->
<div class="modal fade" id="developer_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Developer BSIT 2B</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <div class="row">
                        <div class="col-lg-4">
                            <p>Programmer:</p>
                        </div>
                        <div class="col-lg-8">
                            <p>Batinga, Angel Jhoy T.</p>
                        </div>
                   
                        <div class="col-lg-4">
                            <p>Designer:</p>
                        </div>
                        <div class="col-lg-8">
                            <p>All Members</p>
                        </div>
                    
                        <div class="col-lg-4">
                            <p>Members:</p>
                        </div>
                        <div class="col-lg-8">
                            <p>Arma, Trisha B.</p>
                        </div>
                    
                        <div class="col-lg-4">
                            <p></p>
                        </div>
                        <div class="col-lg-8">
                            <p>Busa, Hanna Jean Ivy B.</p>
                        </div>
                        <div class="col-lg-4">
                            <p></p>
                        </div>
                        <div class="col-lg-8">
                            <p>Capones, Merry Jyza P.</p>
                        </div>
                        <div class="col-lg-4">
                            <p></p>
                        </div>
                        <div class="col-lg-8">
                            <p>Madeja, Irish Katherine L.</p>
                        </div>
                        <div class="col-lg-4">
                            <p></p>
                        </div>
                        <div class="col-lg-8">
                            <p>Magallano, Hannahji B.</p>
                        </div>
                        <div class="col-lg-4">
                            <p>Adviser:</p>
                        </div>
                        <div class="col-lg-8">
                            <p>LAURENCE R. VILLALUZ</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Account Modal -->
<div class="modal fade" id="account_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php $sql = "SELECT * FROM users WHERE id= '". $_SESSION["userID"] ."'"; 
            $result = $conn->query($sql); ?>
            <?php if ($result->num_rows > 0) : ?>
                <?php $row = $result->fetch_assoc(); ?>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-4">
                            <p>First Name:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['firstname'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Middle Name:</p>
                        </div>
                        <div class="col-lg-8">
                            <?php if ($row['middlename'] === NULL || $row['middlename'] === "") : $MI = "N/A"?>
                            <?php else : $MI = $row['middlename']?>
                            <?php endif ?>
                            <p><?= $MI ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Surname:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['surname'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Gender:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['gender'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Birthdate:</p>
                        </div>
                        <div class="col-lg-8">
                            <p>
                            <?php
                                $dateString = $row["birthdate"];
                                $date = new DateTime($dateString);
                                echo $date->format('F j, Y');
                            ?>
                            </p>
                        </div>
                        <div class="col-lg-4">
                            <p>Address:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['address'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Contact Number:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['contact_number'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Email:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['email'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Username:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= $row['username'] ?></p>
                        </div>
                        <div class="col-lg-4">
                            <p>Password:</p>
                        </div>
                        <div class="col-lg-8">
                            <p><?= str_repeat('*', strlen($_SESSION['password'])) ?></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" id="btn_edit_account" class="btn btn-sm text-success tooltip-container" onclick="setValue_edit_account(
                        '<?= $row['firstname'] ?>',
                        '<?= $row['middlename'] ?>',
                        '<?= $row['surname'] ?>',
                        '<?= $row['gender'] ?>',
                        '<?= $row['birthdate'] ?>',
                        '<?= $row['address'] ?>',
                        '<?= $row['contact_number'] ?>',
                        '<?= $row['email'] ?>',
                        '<?= $row['username'] ?>'
                        )" data-toggle="modal" data-target="#edit_account_modal">
                        <i class='fas fa-edit mr-1'></i>
                        <div class="tooltip">Edit Information</div>
                    </button>
                    <button type="button" id="btn_change_password" class="btn btn-sm text-success tooltip-container" data-toggle="modal" data-target="#change_password_modal">
                        <i class='fas fa-key mr-1'></i>
                        <div class="tooltip">Change Password</div>
                    </button>
                    <?php if ($_SESSION["userTYPE"] === "user") : ?>
                    <button type="button" id="btn_delete_account" class="btn btn-sm text-danger tooltip-container">
                        <i class='fas fa-trash-can mr-1'></i>
                        <div class="tooltip">Delete Account</div>
                    </button>
                    <?php endif ?>
                    <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
                </div>
            <?php endif ?>
        </div>
    </div>
</div>

<!-- Edit Account Modal -->
<div class="modal fade" id="edit_account_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Account</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="javascript:void(0)" id="edit_account_form">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="edit_firstname">First Name</label>
                                <input type="text" class="form-control" id="edit_firstname" name="name" placeholder="fisrtname" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_middlename">Middle Name</label>
                                <input type="text" class="form-control" id="edit_middlename" name="name" placeholder="middlename">
                            </div>
                            <div class="form-group">
                                <label for="edit_surname">Surname</label>
                                <input type="text" class="form-control" id="edit_surname" name="name" placeholder="surname" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_gender">Gender</label>
                                <select class="custom-select" id="edit_gender" required>
                                    <option value disabled selected>Gender</option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                    <option value="Tomboy">Tomboy</option>
                                    <option value="Gay">Gay</option>
                                    <option value="Rather not to say">Rather not to say</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="edit_birthday">Birthdate</label>
                                <input type="date" class="form-control" id="edit_birthdate" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="edit_address">Address</label>
                                <input type="text" class="form-control" id="edit_address" name="address" placeholder="address" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_contact_number">Contact Number</label>
                                <input type="text" class="form-control" id="edit_contact_number" name="contact_number" placeholder="Contact Number" required>
                                <small class="text-danger d-none" id="error_edit_contact_number">Contact number is already taken!</small>
                                <small class="text-danger d-none" id="wrong_number">Contact number must start at (+63 or 09)</small>
                            </div>
                            <div class="form-group">
                                <label for="edit_email">Email</label>
                                <input type="email" class="form-control" id="edit_email" name="email" placeholder="email@gmail.com" required>
                                <small class="text-danger d-none" id="error_edit_email">Email is already taken!</small>
                                <small class="text-danger d-none" id="wrong_email">Wrong email format!</small>
                            </div>
                            <div class="form-group">
                                <label for="edit_username">Username</label>
                                <input type="text" class="form-control" id="edit_username" name="username" placeholder="Username" required>
                                <small class="text-danger d-none" id="error_edit_username">Username is already taken!</small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-sm btn-success" id="edit_account_submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal fade" id="change_password_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="javascript:void(0)" id="change_password_form">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="change_password_current_password">Current Password</label>
                        <input type="password" class="form-control" id="change_password_current_password" required>
                        <small class="text-danger d-none" id="error_current_password">Wrong password!</small>
                    </div>
                    <div class="form-group">
                        <label for="change_password_new_password">New Password</label>
                        <input type="password" class="form-control" id="change_password_new_password" required>
                        <small class="text-danger d-none" id="error_edit_new_password">Password did not match!</small>
                    </div>
                    <div class="form-group">
                        <label for="change_password_new_confirm_password">Confirm Password</label>
                        <input type="password" class="form-control" id="change_password_new_confirm_password" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-sm btn-success" id="btn_change_password_submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
