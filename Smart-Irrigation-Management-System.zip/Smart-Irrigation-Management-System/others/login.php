<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="shortcut icon" href="../assets/img/smartLogo.png" type="image/x-icon">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../includes/adminlte/css/adminlte.css">
    
    <style>
        body {
            background-image: url("../assets/img/bg2.png");
            background-repeat: no-repeat;
            background-size: cover;
        }
        .login-card {
            background-color: rgba(255, 255, 255, 0.212);
        }
        .btn-login {
            background-image: linear-gradient(to right, green,  rgb(60, 255, 0));
        }

        .tooltip-container {
            position: relative;
            display: inline-block;
            cursor: pointer;
        }

        .tooltip {
            visibility: hidden;
            width: 120px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 6px;
            padding: 5px 0;
            position: absolute;
            z-index: 1;
            bottom: 125%; /* Adjust according to the desired position */
            left: 50%;
            margin-left: -60px;
            opacity: 0;
            transition: opacity 0.3s;
        }

        .tooltip::after {
            content: "";
            position: absolute;
            top: 100%; /* Adjust according to the desired position */
            left: 50%;
            margin-left: -5px;
            border-width: 5px;
            border-style: solid;
            border-color: #333 transparent transparent transparent;
        }

        .tooltip-container:hover .tooltip {
            visibility: visible;
            opacity: 1;
        }

    </style>
</head>
<body>
   <div class="login-form">
        <div class="user-panel mt-1 pb-2 mb-0 d-flex">
            <div class="image mt-2">
                <img src="../assets/img/smartLogo.png" class="img-circle elevation-0" style="width: 140px; height: 140x; padding: 1px">
            </div>
            <div class="info text-center">
                <h2 class="text-DARK text-bold mt-4">SMART IRRIGATION MANAGEMENT<br>SYSTEM</h2>
            </div>
        </div>
        <div class="d-flex">
            <div class="card-login-form" style=" margin-left: 6%;">
                <div class="card mt-1 elevation-5"  style=" border-radius: 30px;">
                    <div class="card-body">
                        <form action="javascript:void(0)" id="login_form">
                            <div>
                            <a href="homePage.php" class="text-white">
                                <button type="button" class="float-right btn-danger tooltip-container">
                                    <span aria-hidden="true">
                                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                                    </span>
                                    <div class="tooltip">Home</div>
                                </button>
                            </a>
                                <h2 class="text-center text-bold ml-3 mr-3 mt-3 mb-4">LOGIN</h2>
                            </div>
                            <p class="text-center mb-4">Please login to proceed</p>
                            <div class="form-group ml-4 mr-4 mb-3">
                                <label for="login_username">Username</label>
                                <input type="text" class="form-control" id="username" placeholder="username" required>
                                <small class="text-danger d-none " id="error_username">Invalid username!</small>
                            </div>                                        
                            <div class="form-group ml-4 mr-4 mb-3">
                                <label for="login_password">Password</label>
                                <input type="password" class="form-control" id="password" placeholder="password" required>
                                <small class="text-danger d-none " id="error_password">Invalid password!</small>
                                <small class="text-danger d-none " id="error_password_length">Please input at list 8 characters!</small>
                            </div>
                            <a class="ml-4 mr-4" href="javascript:void(0)" id="btn_reset" style="text-decoration: none;" data-toggle="modal" data-target="#forgot_password_modal">Forgot Password?</a>
                            <div class="form-group ml-4 mr-4 mt-3">
                                <button type="submit" class="btn btn-login text-white text-bold ml-4" style="border-radius: 50px; width: 85%;" id="btn_login">LOGIN</button>
                            </div>
                        </form>
                        <div class="ml-4 mr-4 mt-3">
                            <span>Don't have an account?</span>
                            <a href="javascript:void(0)" id="createAccountLink">Create Account</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
  
  
<!-- JQuery JS -->
<script src="../includes/jquery/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="../includes/bootstrap/js/new_bootstrap.min.js"></script>
<!-- AdminLTE JS -->
<script src="../includes/adminlte/js/adminlte.js"></script>
<!-- Font Awesome JS -->
<script src="../includes/fontawesome/js/all.min.js"></script>
<!-- SweetAlert JS -->
<script src="../includes/sweetalert/sweetalert.js"></script>
<script>
    // Optional JavaScript to handle the tooltip display
    const tooltipContainers = document.querySelectorAll('.tooltip-container');

    tooltipContainers.forEach(container => {
        container.addEventListener('mouseenter', () => {
            const tooltip = container.querySelector('.tooltip');
            tooltip.style.display = 'block';
        });

        container.addEventListener('mouseleave', () => {
            const tooltip = container.querySelector('.tooltip');
            tooltip.style.display = 'none';
        });
    });
</script>
<script>
    $(document).ready(function() {
        
        var alert = <?= isset($_SESSION["alert"]) ? json_encode($_SESSION["alert"]) : json_encode(null) ?>;

        if (alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type,
                confirmButtonText: alert.button,
                confirmButtonColor: alert.button_color === 'success' ? '#28a745' : '#3085d6'
            });
        }

        var countdownStartTime = localStorage.getItem("countdown_start_time");
        if (countdownStartTime) {
            var currentTime = Math.floor(Date.now() / 1000); 
            var elapsedTime = currentTime - countdownStartTime;
            var remainingTime = 60 - elapsedTime;

            if (remainingTime > 0) {
                startCountdown(remainingTime);
            } else {
                localStorage.removeItem("countdown_start_time");
            }
        }

        $("#login_form").submit(function() {

            var password = $("#password").val();
            if (password.length < 8) {
                event.preventDefault();
                $("#error_password_length").removeClass("d-none");
                return;
            }

            $("#username").attr("disabled", true);
            $("#password").attr("disabled", true);

            $("#btn_login").attr("disabled", true);
            $("#btn_login").text("Processing...");

            var formData = new FormData();

            formData.append('login', true);
            formData.append("username", $("#username").val());
            formData.append("password", $("#password").val());

            $.ajax({
                url: 'server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.status === "success") {
                        location.href = "../"
                    }
                    else if (response.status === "error_username") {
                        $("#error_username").removeClass("d-none");
                        $("#username").addClass("is-invalid");
                        $("#username").removeAttr("disabled", true);
                        $("#password").removeAttr("disabled", true);
                        $("#btn_login").removeAttr("disabled");
                        $("#btn_login").text("Login");
                    }
                    else if (response.status === "error_password") {
                        $("#error_password").removeClass("d-none");
                        $("#password").addClass("is-invalid");
                        $("#username").removeAttr("disabled", true);
                        $("#password").removeAttr("disabled", true);
                        $("#btn_login").removeAttr("disabled");
                        $("#btn_login").text("Login");
                    }
                    if (response.status === "error_login") {
                        startCountdown(60);

                        $("#btn_login").attr("disabled", true);
                        $("#btn_login").text("Login after (60s)");
                        Swal.fire({
                            title: "Ooops",
                            text: "You have reach the maximum number of login attemt.",
                            icon: "warning",
                            confirmButtonColor: 'success' ? '#28a745' : '#3085d6',
                            confirmButtonText: "OK"
                        })
                    }
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
            $("#username").keypress(function() {
                $("#error_username").addClass("d-none");
                $("#username").removeClass("is-invalid");
            })
            $("#password").keypress(function() {
                $("#error_password").addClass("d-none");
                $("#password").removeClass("is-invalid");
                $("#error_password_length").addClass("d-none");
            })
        })

        function startCountdown(seconds) {
            $("#btn_login").attr("disabled", true);
            $("#btn_login").text("Login after (" + seconds + ")");
            
            var timer = setInterval(function() {
                seconds--;
                if (seconds <= 0) {
                    clearInterval(timer);
                    $("#btn_login").removeAttr("disabled");
                    $("#btn_login").text("LOGIN");
                    localStorage.removeItem("countdown_start_time");
                } else {
                    $("#btn_login").text("Login after (" + seconds + ")");
                }
            }, 1000);

            var currentTime = Math.floor(Date.now() / 1000); 
            localStorage.setItem("countdown_start_time", currentTime);

        }
        
        $("#forgot_password_form").submit(function() {
            $("#btn_forgot_password_submit").attr("disabled", true);
            $("#btn_forgot_password_submit").text("Processing Request...");

            var formData = new FormData();

            formData.append('mailer', true);
            formData.append("email", $("#email_account").val());

            $.ajax({
                url: '../mailer.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {

                    if (response) {
                        location.href = "./email_verification.php"
                    }
                    else {
                        $("#email_account").removeAttr("disabled", true);
                    
                        $("#email_account").addClass("is-invalid");
                        $("#error_email_account").removeClass("d-none");
                    
                        $("#btn_forgot_password_submit").removeAttr("disabled");
                        $("#btn_forgot_password_submit").text("Submit");
                    }
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })
        $("#email_account").keypress(function() {
            $("#error_email_account").addClass("d-none");
            $("#email_account").removeClass("is-invalid");
        })


        $("#createAccountLink").click(function(event){
            event.preventDefault(); // Prevent the default link behavior
            var formData = new FormData();
            formData.append('signUp_session', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./signup.php";
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        });
        
        function sweet_alert(alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type
            });
        }
    })
</script>
<?php unset($_SESSION["alert"]) ?>
<?php include_once "./modals.php" ?>

