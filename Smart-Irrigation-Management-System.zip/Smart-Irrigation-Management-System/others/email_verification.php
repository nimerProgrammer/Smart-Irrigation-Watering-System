<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
    <link rel="shortcut icon" href="../assets/img/smartLogo.png" type="image/x-icon">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../includes/adminlte/css/adminlte.css">
    
    <style>
        body {
            background-image: url("../assets/img/bgi1.jpeg");
            background-repeat: no-repeat;
            background-size: cover;
        }

        .login-form input[type="text"],
        .login-form input[type="password"] {
            border: none;
            border-bottom: 1px solid green;
            border-radius: 0;
            box-shadow: none;
        }

        .login-form input[type="text"]:focus,
        .login-form input[type="password"]:focus {
            border-color: green;
        }

    </style>
</head>
<body>
   <div class="login-form">
        <div class="d-flex h-100 align-items-center justify-content-center">
            <div class="card-login-form">
                <?php if (isset($_SESSION["email_status"])) : ?>
                    <div class="alert alert-<?= $_SESSION["email_status"]["type"] ?> text-center">
                        <?= $_SESSION["email_status"]["message"] ?>
                    </div>
                    <?php unset($_SESSION["email_status"]) ?>
                <?php endif ?>
                <div class="card">
                    <div class="card-header mt-2">
                        <h4 class="text-success">Email Verification</h4>
                    </div>
                    <div class="card-body">
                    <p>Please enter the verification code sent to your email.</p>
                        <form action="javascript:void(0)" id="email_verification_form">
                            <div class="row">
                                <div class="form-group mb-3 col-md-8">
                                    <input type="text" class="form-control" id="email_verification" placeholder="Enter Verification Code" required>
                                    <small class="text-danger d-none" id="error_email_verification">Invalid Code</small>
                                </div>
                                <div class="form-group mb-3 col-md-4">
                                    <button type="button" class="btn btn-success w-100" id="btn_resend_otp">Resend</button>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success w-100" id="btn_verify_submit">Verify</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
  
  
<!-- JQuery JS -->
<script src="../includes/jquery/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="../includes/bootstrap/js/new_bootstrap.min.js"></script>
<!-- AdminLTE JS -->
<script src="../includes/adminlte/js/adminlte.js"></script>
<!-- Font Awesome JS -->
<script src="../includes/fontawesome/js/all.min.js"></script>
<!-- SweetAlert JS -->
<script src="../includes/sweetalert/sweetalert.js"></script>
<script>
    $(document).ready(function() {
        
        var alert = <?= isset($_SESSION["alert"]) ? json_encode($_SESSION["alert"]) : json_encode(null) ?>;

        if (alert) {
            sweet_alert(alert);
        }

        var countdownStartTime = localStorage.getItem("countdown_start_time");
        if (countdownStartTime) {
            var currentTime = Math.floor(Date.now() / 1000); 
            var elapsedTime = currentTime - countdownStartTime;
            var remainingTime = 60 - elapsedTime;

            if (remainingTime > 0) {
                startCountdown(remainingTime);
            } else {
                localStorage.removeItem("countdown_start_time");
            }
        }

        $("#btn_resend_otp").click(function() {

            startCountdown(60);
                
            var formData = new FormData();
            formData.append('resend_mail', true);

            $.ajax({
                url: '../mailer.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./email_verification.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        function startCountdown(seconds) {
            $("#btn_resend_otp").attr("disabled", true);
            $("#btn_resend_otp").text("Resend (" + seconds + ")");
 
            var timer = setInterval(function() {
                seconds--;
                if (seconds <= 0) {
                    clearInterval(timer);
                    $("#btn_resend_otp").removeAttr("disabled");
                    $("#btn_resend_otp").text("Resend");
                    localStorage.removeItem("countdown_start_time");
                } else {
                    $("#btn_resend_otp").text("Resend (" + seconds + ")");
                }
            }, 1000);

            var currentTime = Math.floor(Date.now() / 1000); 
            localStorage.setItem("countdown_start_time", currentTime);
        }

        $("#email_verification_form").submit(function() {

            $("#btn_verify_submit").attr("disabled", true);
            $("#btn_verify_submit").text("Processing...");

            var formData = new FormData();

            formData.append('email_verification', true);
            formData.append('code', $('#email_verification').val());

            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response) {
                        location.href = "./change_password.php"
                    }
                    else {
                        $("#btn_verify_submit").removeAttr("disabled", true);
                        $("#btn_verify_submit").text("Verify");

                        $('#error_email_verification').removeClass('d-none');
                        $('#email_verification').addClass('is-invalid');
                    }
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })
        $("#email_verification").keypress(function() {
            $("#error_email_verification").addClass("d-none");
            $("#email_verification").removeClass("is-invalid");
        })

        function sweet_alert(alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type
            });
        }
    })
</script>
<?php unset($_SESSION["alert"]) ?>
