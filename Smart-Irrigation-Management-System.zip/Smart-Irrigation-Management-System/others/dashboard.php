<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["userTYPE"])) {
    header("location: login.php");
}
?>
<?php include_once "header.php" ?>

<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-lg-6">
                    <h2 class="mt-3 text-success">
                        <i class="nav-icon fa-solid fa-chart-line"></i>
                        Dashboard
                    </h2>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <?php if ($_SESSION["userTYPE"] === "admin") : ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            USERS
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <?php 
                                            $sql1 = "SELECT * FROM users WHERE account_status='Activated'";
                                            $result1 = $conn->query($sql1);
                                            ?>
                                            <h2 style="color: #28a745;"><?= $result1->num_rows ?></h2>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            DATA ANALYTICS
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-bar fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif ?>
        <?php if ($_SESSION["userTYPE"] === "user") : ?>
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            WATER USAGE
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-droplet fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            SOIL MOISTURE
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-temperature-high fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            REAL TIME MONITORING
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-calendar-check fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            SMART ALERTS
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-bell fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-md-6 mb-4">
                        <div class="card shadow h-80 py-3" style="border-radius: 10px; border: 1px solid #28a745;">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="font-weight-bold" style="color: #28a745; font-size: 18px;">
                                            DATA ANALYTICS
                                        </div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800 text-center">
                                            <h5 class="text-gray">Under development</h5>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-bar fa-4x " style="color: #28a745;"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif ?>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-lg-6">
                    <h1 class="mt-3 text-gray">
                        This feature is in progress.
                    </h1>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include_once "footer.php" ?>



