<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="shortcut icon" href="../assets/img/smartLogo.png" type="image/x-icon">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- AdminLTE CSS -->
    <link rel="stylesheet" href="../includes/adminlte/css/adminlte.css">
    <!-- Bootstrap CSS -->
    <link href="../includes/bootstrap/css/bootstrap.min1.css" rel="stylesheet">
    <!-- Bootstrap JS -->
    <script src="../includes/bootstrap/js/bootstrap.bundle.min1.js"></script>
    <style>
        body {
            background-image: url("../assets/img/homePage.png");
            background-repeat: no-repeat;
            background-size: cover;
        }
        nav {
            height: 60px;
            background-color: rgba(1, 119, 1, 0.705);
            text-align: center;
        }
        ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }
        li {
            display: inline-block;
            margin-right: 20px; 
            font-size: 20px;
        }
        a {
            display: block;
            color: white;
            padding: 10px 20px; 
            text-decoration: none;
            transition: background-color 0.3s; 
        }
        a:hover {
            background-color: #28a745; 
            color: white;
        }
        .btn-login {
            font-weight: bold;
            background-color: rgba(0, 151, 0, 0.774);
        }
        .btn-custom:hover {
            background-color: #28a745;
        }
        .btn-custom {
            border-radius: 50px;
            width: 100%;
            font-size: 20px;
            font-weight: bold;
            border-color:  white;
            background-color: rgba(0, 151, 0, 0.774);
        }
        .margin-left-10 {
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container-fluid">
        <li class="nav-item active" style="margin-right: 5px;">
            <img id="sidebar-logo" src="../assets/img/smartLogo.png" class="img-circle elevation-0 ml-2" style="width: 60px; height: 60px; padding: 1px;" alt="Header Image">
        </li>
        <h3 class="d-block d-md-inline mt-2 text-white text-bold">Smart Irrigation Management System</h3>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasDarkNavbar" aria-controls="offcanvasDarkNavbar" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end text-bg-success" tabindex="-1" id="offcanvasDarkNavbar" aria-labelledby="offcanvasDarkNavbarLabel">
          <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasDarkNavbarLabel">Smart Irrigation Management System</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                <li class="nav-item active">
                    <a href="javascript:void(0)" class="nav-link text-white">Home</a>
                </li>
                <li class="nav-item active">
                    <a href="javascript:void(0)" class="nav-link text-white">About</a>
                </li>
                <li class="nav-item active">
                    <a href="javascript:void(0)" class="nav-link text-white">Services</a>
                </li>
                <li class="nav-item active">
                    <a href="javascript:void(0)" class="nav-link text-white">Contact</a>
                </li>
            </ul>
            <!-- <form class="d-flex mt-3" role="search">
              <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-success" type="submit">Search</button>
            </form> -->
          </div>
        </div>
      </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="row" style="margin-top: 18%">
                <div class="col-lg-6 d-flex justify-content-end">
                    <div class="form-group">
                        <a href="./login.php" type="button" class="btn btn-login text-white text-bold btn-custom" style="width: 300px;" id="btn_login">
                            LOGIN
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 d-flex justify-content-start">
                    <div class="form-group">
                        <a href="javascript:void(0)" id="createAccountLink" class="btn btn-success text-white text-bold btn-custom margin-left-10" style="width: 300px;" id="btn_signup">
                            SIGNUP
                        </a>
                    </div>
                </div>
                <div class="col-12">
                    <h1 class="text-dark" style="margin-top:5%; margin-left:30%">
                        This feature is in progress.
                    </h1>
                </div>
            </div>
        </div>
    </div>
</div>


    <!-- JQuery JS -->
    <script src="../includes/jquery/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="../includes/bootstrap/js/bootstrap.bundle.min1.js"></script>
    <!-- AdminLTE JS -->
    <script src="../includes/adminlte/js/adminlte.js"></script>
    <!-- Font Awesome JS -->
    <script src="../includes/fontawesome/js/all.min.js"></script>
    <!-- SweetAlert JS -->
    <script src="../includes/sweetalert/sweetalert.js"></script>
</body>
</html>

<script>
    $(document).ready(function() {
        
        var alert = <?= isset($_SESSION["alert"]) ? json_encode($_SESSION["alert"]) : json_encode(null) ?>;

        if (alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type,
                confirmButtonText: alert.button,
                confirmButtonColor: alert.button_color === 'success' ? '#28a745' : '#3085d6'
            });
        }

        $("#createAccountLink").click(function(event){
            event.preventDefault(); // Prevent the default link behavior
            var formData = new FormData();
            formData.append('signUp_session', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./signup.php";
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        });

        function sweet_alert(alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type
            });
        }
    })
</script>
<?php unset($_SESSION["alert"]) ?>
<?php include_once "./modals.php" ?>

