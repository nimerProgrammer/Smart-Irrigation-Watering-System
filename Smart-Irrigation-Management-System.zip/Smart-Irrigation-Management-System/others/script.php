<script>
    $(document).ready(function() {
        var alert = <?= isset($_SESSION["alert"]) ? json_encode($_SESSION["alert"]) : json_encode(null) ?>;

        if (alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type,
                confirmButtonText: alert.button,
                confirmButtonColor: alert.button_color === 'success' ? '#28a745' : '#3085d6'
            });
        }

        $(".nav-link").click(function() {
            $(this).children(".tab_spinner").removeClass("d-none");
        })

        if ('<?= $_SESSION["thisTab"] ?>' === 'Real Time Monitoring' || 
            '<?= $_SESSION["thisTab"] ?>' === 'Automated Scheduling' || 
            '<?= $_SESSION["thisTab"] ?>' === 'Smart Alerts' || 
            '<?= $_SESSION["thisTab"] ?>' === 'Data Analytics') {
            
            $('#features_submenu').show();
            $('#btn_icon').removeClass('fa-angle-right').addClass('fa-angle-down');
        }

        $('#btn_features').on('click', function(event) {
            event.stopPropagation();
            $('#features_submenu').toggle();
            $('#btn_icon').toggleClass('fa-angle-right fa-angle-down');
        });

        $('#btn_features').on('click', function(event) {
            if (!$(event.target).closest('#features_submenu, #btn_features').length) {
                if ($('#features_submenu').is(':visible')) {
                    $('#features_submenu').hide();
                    $('#btn_icon').removeClass('fa-angle-down').addClass('fa-angle-right');
                }
            }
        });

        $(".datatable").DataTable({
            "responsive": true,
            "lengthChange": true,
            "bPaginate": true,
            "bLengthChange": true,
            "bFilter": true,
            "bInfo": false,
            "bAutoWidth": false,
            "targets": 'no-sort',
            "bSort": false,
            "order": []
        })

        $("#btn_dashboard").click(function() {
            var formData = new FormData();
            formData.append('dashboard', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "../"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_real_time_monitoring").click(function() {
            var formData = new FormData();
            formData.append('real_time_monitoring', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./real_time_monitoring.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_automated_scheduling").click(function() {
            var formData = new FormData();
            formData.append('automated_scheduling', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./automated_scheduling.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_smart_alerts").click(function() {
            var formData = new FormData();
            formData.append('smart_alerts', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./smart_alerts.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_data_analytics").click(function() {
            var formData = new FormData();
            formData.append('data_analytics', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./data_analytics.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_water_usage").click(function() {
            var formData = new FormData();
            formData.append('water_usage', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./water_usage.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_soil_moisture").click(function() {
            var formData = new FormData();
            formData.append('soil_moisture', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./soil_moisture.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_user_management").click(function() {
            var formData = new FormData();
            formData.append('user_management', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./user_management.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_reports").click(function() {
            var formData = new FormData();
            formData.append('reports', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./reports.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $("#btn_settings").click(function() {
            var formData = new FormData();
            formData.append('settings', true);
            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./settings.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })

        $(".btn_logout").click(function() {
            Swal.fire({
                title: "Confirm Logout",
                text: "Are you sure you want to logout?",
                icon: "question",
                showCancelButton: true,
                confirmButtonColor: "#28a745",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, logout"
            }).then((result) => {
                if (result.isConfirmed) {
                    var formData = new FormData();

                    formData.append('logout', true);

                    $.ajax({
                        url: './server.php',
                        data: formData,
                        type: 'POST',
                        dataType: 'JSON',
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            location.href = "../";
                        },
                        error: function(xhr, status, error) {
                            console.error(error);
                        }
                    });
                }
            });
        })

        $('#edit_contact_number').on('keydown input', function(e) {
            var value = $(this).val();

            // Allow only digits and + sign
            var regex = /^[0-9+]*$/;
            if (!regex.test(value)) {
                $(this).val(value.replace(/[^0-9+]/g, ''));
                return;
            }

            // Check for max length based on initial character
            var maxLength;
            if (value.startsWith('+')) {
                maxLength = 13;
            } else if (value.startsWith('0')) {
                maxLength = 11;
            } else {
                maxLength = 13; // Default max length for unexpected cases
            }

            // Prevent further input if max length is reached
            if ($(this).val().length >= maxLength && e.keyCode !== 8 && e.keyCode !== 46) {
                e.preventDefault();
            }

            // Ensure the + sign is only at the beginning
            if (value.indexOf('+') > 0) {
                $(this).val(value.replace(/\+/g, ''));
            }

            // Update the value to ensure only valid characters are present
            $(this).val(value);
        });

        $("#edit_contact_number").keyup(function(){
            var maxLength = parseInt($(this).attr('maxlength'));
            if ($(this).val().length < maxLength) {
                $(this).css('color', 'red');

            } else {
                $(this).css('color', ''); // Reset to default color
            }

            $("#edit_contact_number").keyup(function(){
                var val = $('#edit_contact_number').val();

                // Check if the value starts with '09' or '+63'
                if (val.startsWith('+63')) {
                    $(this).css('color', ''); 
                    $('#wrong_number').addClass('d-none');
                    $('#contact_number').removeClass('is-invalid');
                } 
                else if (val.startsWith('09')) {
                    $(this).css('color', ''); 
                    $('#wrong_number').addClass('d-none');
                    $('#edit_contact_number').removeClass('is-invalid');
                }
                else {
                    $(this).css('color', 'red');
                    $('#wrong_number').removeClass('d-none');
                    $('#edit_contact_number').addClass('is-invalid');
                }
            });      
        });

        $("#edit_email").on('input', function(){
            var email = $(this).val();
            if (email.length >= 10 && email.substr(-10) !== "@gmail.com") {
                $(this).css('color', 'red');
                $('#wrong_email').removeClass('d-none');
                $('#edit_email').addClass('is-invalid');
            } else {
                $(this).css('color', ''); // Reset to default color
                $('#wrong_email').addClass('d-none');
                $('#edit_email').removeClass('is-invalid');
            }
        });

        $("#edit_account_form").submit(function() {
            var formData = new FormData();
            formData.append("firstname", $("#edit_firstname").val());
            formData.append("middlename", $("#edit_middlename").val());
            formData.append("surname", $("#edit_surname").val());
            formData.append("gender", $("#edit_gender").val());
            formData.append("birthdate", $("#edit_birthdate").val());
            formData.append("address", $("#edit_address").val());
            formData.append("contact_number", $("#edit_contact_number").val());
            formData.append("email", $("#edit_email").val());
            formData.append("username", $("#edit_username").val());
            formData.append("edit_account", true);

            $("#edit_account_submit").attr("disabled", true);
            $("#edit_account_submit").text("Processing...");

            // AJAX request
            $.ajax({
                url: 'server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    // Handle successful response
                    if (response.status === 'success') {
                        if ("<?= $_SESSION["thisTab"] ?>" === "Dashboard") {
                            location.href = "./dashboard.php"
                        }
                    }
                    else if (response.status === 'error_contact_number') {
                        $("#edit_account_submit").removeAttr("disabled", true);
                        $("#edit_account_submit").text("Sign up");

                        $('#error_edit_contact_number').removeClass('d-none');
                        $('#edit_contact_number').addClass('is-invalid');

                        $("#error_edit_email").addClass("d-none");
                        $("#edit_email").removeClass("is-invalid");
                        $("#error_edit_username").addClass("d-none");
                        $("#edit_username").removeClass("is-invalid");
                    }
                    else if (response.status === 'error_email') {
                        $("#edit_account_submit").removeAttr("disabled", true);
                        $("#edit_account_submit").text("Sign up");

                        $('#error_edit_email').removeClass('d-none');
                        $('#edit_email').addClass('is-invalid');

                        $("#error_edit_contact_number").addClass("d-none");
                        $("#edit_contact_number").removeClass("is-invalid");
                        $("#error_edit_username").addClass("d-none");
                        $("#edit_username").removeClass("is-invalid");
                    }
                    else if (response.status === 'error_username') {
                        $("#edit_account_submit").removeAttr("disabled", true);
                        $("#edit_account_submit").text("Sign up");

                        $('#error_edit_username').removeClass('d-none');
                        $('#edit_username').addClass('is-invalid');

                        $("#error_edit_contact_number").addClass("d-none");
                        $("#edit_contact_number").removeClass("is-invalid");
                        $("#error_edit_email").addClass("d-none");
                        $("#edit_email").removeClass("is-invalid");
                    }
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error(error);
                }
            });
        })
        $("#edit_contact_number").keypress(function() {
            $("#error_edit_contact_number").addClass("d-none");
            $("#edit_contact_number").removeClass("is-invalid");
        })
        $("#edit_email").keypress(function() {
            $("#error_edit_email").addClass("d-none");
            $("#edit_email").removeClass("is-invalid");
        })
        $("#edit_username").keypress(function() {
            $("#error_edit_username").addClass("d-none");
            $("#edit_username").removeClass("is-invalid");
        })
    
        $('#change_password_form').submit(function(e) {
            var formData = new FormData();
            formData.append("newPassword", $("#change_password_new_password").val());
            formData.append("change_password", true);

            $("#btn_change_password_submit").attr("disabled", true);
            $("#btn_change_password_submit").text("Processing...");

            // Check if passwords match
            var currentPassword = $('#change_password_current_password').val();
            var newPassword = $('#change_password_new_password').val();
            var confirmPassword = $('#change_password_new_confirm_password').val();

            if ("<?= $_SESSION['password'] ?>" !== currentPassword) {
                $("#btn_change_password_submit").removeAttr("disabled", true);
                $("#btn_change_password_submit").text("Submit");

                $('#error_current_password').removeClass('d-none');
                $('#change_password_current_password').addClass('is-invalid');
                return;
            }
            else {
                $('#error_current_password').addClass('d-none');
                $('#change_password_current_password').removeClass('is-invalid');
            }
            if (newPassword !== confirmPassword) {
                $("#btn_change_password_submit").removeAttr("disabled", true);
                $("#btn_change_password_submit").text("Submit");

                $('#error_edit_new_password').removeClass('d-none');
                $('#change_password_new_password').addClass('is-invalid');
                $('#change_password_new_confirm_password').addClass('is-invalid');
                return;
            } else {
                $('#error_edit_new_password').addClass('d-none');
                $('#change_password_new_password').removeClass('is-invalid');
                $('#change_password_new_confirm_password').removeClass('is-invalid');
            }

            // AJAX request
            $.ajax({
                url: 'server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    // Handle successful response
                    if (response.status === 'success') {
                        if ("<?= $_SESSION["thisTab"] ?>" === "Dashboard") {
                            location.href = "./dashboard.php"
                        }
                        else if ("<?= $_SESSION["thisTab"] ?>" === "Books") {
                            location.href = "./books.php"
                        }
                        else if ("<?= $_SESSION["thisTab"] ?>" === "Request Receipt") {
                            location.href = "./request_receipt.php"
                        }
                        else if ("<?= $_SESSION["thisTab"] ?>" === "Receipted Books") {
                            location.href = "./receipted_books.php"
                        }
                        else if ("<?= $_SESSION["thisTab"] ?>" === "Returned Books") {
                            location.href = "./returned_books.php"
                        }
                    }
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    console.error(error);
                }
            });
        });
        $("#change_password_current_password").keypress(function() {
            $("#error_current_password").addClass("d-none");
            $("#change_password_current_password").removeClass("is-invalid");
        })
        $("#change_password_new_password").keypress(function() {
            $("#error_edit_new_password").addClass("d-none");
            $("#change_password_new_password").removeClass("is-invalid");
            $("#change_password_new_confirm_password").removeClass("is-invalid");
        })
        $("#change_password_new_confirm_password").keypress(function() {
            $("#error_edit_new_password").addClass("d-none");
            $("#change_password_new_password").removeClass("is-invalid");
            $("#change_password_new_confirm_password").removeClass("is-invalid");
        })

        $("#btn_delete_account").click(function() {
            Swal.fire({
                title: "Confirmation",
                text: "Are you sure you want to delete your account?",
                icon: "question",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes"
            }).then((result) => {
                if (result.isConfirmed) {

                    var formData = new FormData();
                    formData.append('delete_account', true);

                    $.ajax({
                        url: './server.php',
                        data: formData,
                        type: 'POST',
                        dataType: 'JSON',
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            location.href = "./login.php"
                        },
                        error: function(xhr, status, error) {
                            console.error(error);
                        }
                    });
                }
            })
        })

        function sweet_alert(alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type
            });
        }
    })
    
</script>