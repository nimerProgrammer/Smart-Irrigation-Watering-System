<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();

    if (!isset($_SESSION["change_password"])) {
        header("location: login.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="shortcut icon" href="../assets/img/bgi1.jpeg" type="image/x-icon">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../includes/adminlte/css/adminlte.css">
    
    <style>
        body {
            background-image: url("../assets/img/bgi1.jpeg");
            background-repeat: no-repeat;
            background-size: cover;
        }

        .login-form input[type="text"],
        .login-form input[type="password"] {
            border: none;
            border-bottom: 1px solid green;
            border-radius: 0;
            box-shadow: none;
        }

        .login-form input[type="text"]:focus,
        .login-form input[type="password"]:focus {
            border-color: green;
        }

    </style>
</head>
<body>
   <div class="login-form">
        <div class="d-flex h-100 align-items-center justify-content-center">
            <div class="card-login-form">
                <div class="card">
                    <div class="card-header mt-2">
                        <h4 class="text-success">Change Password</h4>
                    </div>
                    <div class="card-body">
                        <form action="javascript:void(0)" id="change_password_form">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="password"placeholder="New Password" required>
                                        <small class="text-danger d-none" id="error_password">Password doesn't match!</small>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input type="password" class="form-control" id="confirm_password" placeholder="Confirm-password" required>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success w-100" id="btn_submit">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
  
  
<!-- JQuery JS -->
<script src="../includes/jquery/jquery-3.6.0.min.js"></script>
<!-- Bootstrap JS -->
<script src="../includes/bootstrap/js/new_bootstrap.min.js"></script>
<!-- AdminLTE JS -->
<script src="../includes/adminlte/js/adminlte.js"></script>
<!-- Font Awesome JS -->
<script src="../includes/fontawesome/js/all.min.js"></script>
<!-- SweetAlert JS -->
<script src="../includes/sweetalert/sweetalert.js"></script>
<script>
    $(document).ready(function() {
        
        var alert = <?= isset($_SESSION["alert"]) ? json_encode($_SESSION["alert"]) : json_encode(null) ?>;

        if (alert) {
            sweet_alert(alert);
        }

        $("#change_password_form").submit(function() {

            $("#btn_submit").attr("disabled", true);
            $("#btn_submit").text("Processing...");

            var formData = new FormData();

            formData.append('change_password', true);
            formData.append('newPassword', $('#password').val());

            var password = $('#password').val();
            var confirmPassword = $('#confirm_password').val();
            if (password !== confirmPassword) {
                $("#btn_submit").removeAttr("disabled", true);
                $("#btn_submit").text("Submit");

                $('#error_password').removeClass('d-none');
                $('#password').addClass('is-invalid');
                $('#confirm_password').addClass('is-invalid');
                return;
            } else {
                $('#error_password').addClass('d-none');
            }

            $.ajax({
                url: './server.php',
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function(response) {
                    location.href = "./login.php"
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        })
        $("#password").keypress(function() {
            $("#error_password").addClass("d-none");
            $("#password").removeClass("is-invalid");
            $("#confirm_password").removeClass("is-invalid");
        })
        $("#confirm_password").keypress(function() {
            $("#error_password").addClass("d-none");
            $("#password").removeClass("is-invalid");
            $("#confirm_password").removeClass("is-invalid");
        })

        function sweet_alert(alert) {
            Swal.fire({
                title: alert.title,
                text: alert.message,
                icon: alert.type
            });
        }
    })
</script>
<?php unset($_SESSION["alert"]) ?>
        
                    
